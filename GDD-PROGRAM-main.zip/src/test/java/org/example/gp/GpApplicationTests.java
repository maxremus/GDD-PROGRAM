package org.example.gp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpApplicationTests {

    @Test
    void contextLoads() {
    }

}
